// import { ref, computed } from 'vue';
// import { defineStore } from 'pinia';
// import axios from 'axios';
// import { useLocalStorage } from '@vueuse/core';

// export const useAuth = defineStore('authStore', () => {
// 	const user = useLocalStorage('user', {});
// 	const token = useLocalStorage('userToken', null);

// 	const isLoggedIn = computed(() => (token.value && user.value ? true : false));

// 	const setUser = (payload) => {
// 		user.value = payload;
// 	};

// 	const setToken = (payload) => {
// 		token.value = payload;
// 	};

// 	const getUser = async () => {
// 		// /api/processregistration
// 		try {
// 			await axios
// 				.get(`/getinfo?id=${user.value.id}&email=${user.value.email}`)
// 				.then((res) => {
// 					// console.log(res.data.data)
// 					setUser(res.data.data);
// 				})
// 				.catch((err) => {
// 					console.log(err);
// 				});
// 		} catch (error) {
// 			console.log(error);
// 		}
// 	};

// 	const loginUser = async (payload) => {
// 		// /api/login
// 		const { username, password } = payload;
// 		try {
// 			let data = await axios.post('/login', {
// 				username,
// 				password,
// 			});
// 			return data;
// 		} catch (error) {
// 			return error;
// 		}
// 	};

// 	return {
// 		isLoggedIn,
// 		setUser,
// 		setToken,
// 		user,
// 		token,
// 		loginUser,
// 		getUser,
// 	};
// });

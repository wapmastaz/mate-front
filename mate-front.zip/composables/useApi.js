import axios from 'axios';

export const useApi = () => {
	const baseURL = 'http://mate-africa.test/api/v1/';

	return axios.create({
		baseURL,
		headers: {
			Authorization: `Basic `,
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*',
			Accept: 'application/json',
		},
	});
};

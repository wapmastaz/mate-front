<template>
	<div data-theme="light">
		<AppHeader />
		<slot />
		<AppFooter />
	</div>
</template>

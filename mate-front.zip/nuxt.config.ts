// https://nuxt.com/docs/api/configuration/nuxt-config
import { defineNuxtModule } from 'nuxt';

export default defineNuxtConfig({
	modules: [
		'@nuxtjs/tailwindcss',
		'nuxt-swiper',
		'nuxt-icon',
		'@formkit/nuxt',
    '@pinia/nuxt',
	],
	devtools: { enabled: true },
	css: ['~/assets/css/main.css'],
	app: {
		pageTransition: { name: 'slide-fade-left', mode: 'out-in' },
	},
	swiper: {
		prefix: 'Swiper',
	},

	formkit: {
		autoImport: true,
	},
  
	devServer: {
		host: '--host',
	},
});

const index_vue_vue_type_style_index_0_scoped_c5b5856d_lang = ".card.image-full[data-v-c5b5856d]:before{opacity:.35!important}";

const indexStyles_22fb9cd1 = [index_vue_vue_type_style_index_0_scoped_c5b5856d_lang, index_vue_vue_type_style_index_0_scoped_c5b5856d_lang];

export { indexStyles_22fb9cd1 as default };
//# sourceMappingURL=index-styles.22fb9cd1.mjs.map

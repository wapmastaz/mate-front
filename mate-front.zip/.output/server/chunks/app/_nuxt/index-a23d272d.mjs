import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { _ as __nuxt_component_0 } from './nuxt-link-afaf4e47.mjs';
import { useSSRContext, ref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, createTextVNode, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '../server.mjs';
import 'vue-router';

const partner1 = "" + publicAssetsURL("img/partners/1.png");
const partner2 = "" + publicAssetsURL("img/partners/2.png");
const partner3 = "" + publicAssetsURL("img/partners/3.png");
const partner4 = "" + publicAssetsURL("img/partners/4.png");
const partner5 = "" + publicAssetsURL("img/partners/5.png");
const partner6 = "" + publicAssetsURL("img/partners/6.png");
const partner7 = "" + publicAssetsURL("img/partners/7.png");
const _sfc_main$1 = {
  __name: "Partner",
  __ssrInlineRender: true,
  setup(__props) {
    const partners = ref([
      {
        name: "partner1",
        img: partner1
      },
      {
        name: "partner2",
        img: partner2
      },
      {
        name: "partner3",
        img: partner3
      },
      {
        name: "partner4",
        img: partner4
      },
      {
        name: "partner5",
        img: partner5
      },
      {
        name: "partner6",
        img: partner6
      },
      {
        name: "partner7",
        img: partner7
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-10 container mx-auto px-4" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Swiper, {
        "slides-per-view": 7,
        loop: true,
        effect: "fade",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        navigation: false
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(partners.value, (partner) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                key: partner.name
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<img class="w-20 h-4 fill-accent-content mx-auto"${ssrRenderAttr("src", partner.img)}${ssrRenderAttr("alt", partner.name)}${_scopeId2}>`);
                  } else {
                    return [
                      createVNode("img", {
                        class: "w-20 h-4 fill-accent-content mx-auto",
                        src: partner.img,
                        alt: partner.name
                      }, null, 8, ["src", "alt"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(partners.value, (partner) => {
                return openBlock(), createBlock(_component_SwiperSlide, {
                  key: partner.name
                }, {
                  default: withCtx(() => [
                    createVNode("img", {
                      class: "w-20 h-4 fill-accent-content mx-auto",
                      src: partner.img,
                      alt: partner.name
                    }, null, 8, ["src", "alt"])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Partner.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$1;
const _imports_0 = "" + publicAssetsURL("img/innovation.png");
const _imports_1 = "" + publicAssetsURL("img/services/1.png");
const _imports_2 = "" + publicAssetsURL("img/services/2.png");
const slider1 = "" + publicAssetsURL("img/hero-slider/1.png");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const sliders = ref([
      {
        name: "slider 1",
        img: slider1
      }
    ]);
    const whyChooseUs = ref([
      {
        title: "Tailored Solutions",
        content: "We do not operate one-size-fits-all solutions strategy. Dunvipe offers customized services designed to meet your unique business and individual needs and objectives, ensuring optimal results."
      },
      {
        title: "Proven Track Record",
        content: "Our history of delivering outstanding results and fostering long-term partnerships with our existing partners speaks volumes. With Dunvipe, you can rely on our ability to deliver on our promise."
      },
      {
        title: "Strategic Partnerships",
        content: "We view our clients as partners, not just customers. Dunvipe is dedicated to building strategic alliances and collaborative relationships that drive mutual growth and success."
      },
      {
        title: "Global Reach",
        content: "Our services are not limited by geographical boundaries. Dunvipe serves clients internationally, providing support and solutions wherever you operate"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      const _component_nuxt_link = __nuxt_component_0;
      const _component_Partner = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-c5b5856d><section data-v-c5b5856d><div class="hero min-h-[80vh] bg-white py-16 sm:py-4" data-v-c5b5856d><div class="container mx-auto px-4" data-v-c5b5856d><div class="hero-content grid grid-cols-1 sm:grid-cols-2 gap-8 sm:gap-4" data-v-c5b5856d><div data-v-c5b5856d><h3 class="text-secondary text-lg uppercase mb-6" data-v-c5b5856d> Efficiency meets reliability </h3><h1 class="text-5xl font-medium" data-v-c5b5856d> Fuel your growth through trusted solutions </h1><p class="py-6 text-lg" data-v-c5b5856d> We pride ourselves as a trusted advisory that partners with businesses of different sizes to provide IT and Energy based solutions. </p><button class="btn btn-outline rounded-3xl" data-v-c5b5856d>Discover more</button></div><div class="hidden sm:block" data-v-c5b5856d>`);
      _push(ssrRenderComponent(_component_Swiper, {
        "slides-per-view": 1,
        loop: true,
        effect: "fade",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        navigation: true
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(sliders.value, (slide) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                key: slide.name
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<img class="w-[85%] sm:w-[70%] mx-auto"${ssrRenderAttr("src", slide.img)}${ssrRenderAttr("alt", slide.name)} data-v-c5b5856d${_scopeId2}>`);
                  } else {
                    return [
                      createVNode("img", {
                        class: "w-[85%] sm:w-[70%] mx-auto",
                        src: slide.img,
                        alt: slide.name
                      }, null, 8, ["src", "alt"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(sliders.value, (slide) => {
                return openBlock(), createBlock(_component_SwiperSlide, {
                  key: slide.name
                }, {
                  default: withCtx(() => [
                    createVNode("img", {
                      class: "w-[85%] sm:w-[70%] mx-auto",
                      src: slide.img,
                      alt: slide.name
                    }, null, 8, ["src", "alt"])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></section><section class="bg-[#000306] py-10 rounded-tr-[7rem]" data-v-c5b5856d><div class="container mx-auto px-4" data-v-c5b5856d><article class="grid grid-cols-1 sm:grid-cols-2 gap-8 sm:gap-4" data-v-c5b5856d><div class="" data-v-c5b5856d><h3 class="text-white text-lg font-semibold mb-4" data-v-c5b5856d>About Us</h3><h2 class="text-3xl font-semibold text-secondary mb-4" data-v-c5b5856d> Welcome to where efficiency meets <span class="text-primary" data-v-c5b5856d>innovation</span></h2><p class="prose text-white/90 mb-4" data-v-c5b5856d> At Dunvipe Group, we\u2019re committed to delivering excellence that helps navigate the dynamic landscape of the energy and technological industries. We have an unmatched understanding of our clients\u2019 needs in line the ever-evolving market dynamics and are committed to not only providing efficient and outstanding services, but being a trusted advisory that fosters our client\u2019s growth, business opportunities and builds a bridge of lasting partnerships. </p>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/about",
        class: "btn btn-secondary rounded-3xl px-8"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Read more`);
          } else {
            return [
              createTextVNode("Read more")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div data-v-c5b5856d><img${ssrRenderAttr("src", _imports_0)} alt="" data-v-c5b5856d></div></article></div></section><section class="bg-[#000306] py-10" data-v-c5b5856d><div class="container mx-auto px-4" data-v-c5b5856d><article class="" data-v-c5b5856d><div class="text-center" data-v-c5b5856d><h3 class="text-white text-lg font-semibold mb-4" data-v-c5b5856d>Our Services</h3><h2 class="text-3xl font-semibold text-secondary mb-2" data-v-c5b5856d> Let\u2019s Tunnel down </h2><p class="text-white text-sm" data-v-c5b5856d>Zero in on your required solution</p></div></article><article class="flex flex-col sm:flex-row gap-4 mt-16 justify-center items-center" data-v-c5b5856d><div class="card w-full sm:w-96 bg-dark shadow-xl image-full" data-v-c5b5856d><figure data-v-c5b5856d><img${ssrRenderAttr("src", _imports_1)} alt="service 1" data-v-c5b5856d></figure><div class="card-body items-center justify-end" data-v-c5b5856d><h2 class="card-title text-2xl" data-v-c5b5856d>Oil &amp; Gas</h2>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/asd",
        class: "text-primary text-lg font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Discover more `);
          } else {
            return [
              createTextVNode(" Discover more ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="card w-full sm:w-96 bg-dark shadow-xl image-full" data-v-c5b5856d><figure data-v-c5b5856d><img${ssrRenderAttr("src", _imports_2)} alt="service 2" data-v-c5b5856d></figure><div class="card-body items-center justify-end" data-v-c5b5856d><h2 class="card-title text-2xl" data-v-c5b5856d>Information Technology</h2>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/asd",
        class: "text-primary text-lg font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Discover more `);
          } else {
            return [
              createTextVNode(" Discover more ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></article></div></section>`);
      _push(ssrRenderComponent(_component_Partner, null, null, _parent));
      _push(`<section class="py-10" data-v-c5b5856d><div class="container mx-auto px-4" data-v-c5b5856d><article class="grid grid-cols-2 gap-4 max-w-3xl mx-auto" data-v-c5b5856d><div class="text-left" data-v-c5b5856d><h3 class="text-secondary text-lg font-semibold mb-4" data-v-c5b5856d> Why choose us? </h3><h2 class="text-3xl font-semibold mb-2" data-v-c5b5856d> Multidisciplinary Expertise </h2></div><div class="text-left" data-v-c5b5856d><p class="prose text-sm" data-v-c5b5856d> Dunvipe brings together a team of experts with deep knowledge and experience in both the Oil &amp; Gas and IT sectors, providing clients with holistic solutions that bridge the gap between technology and energy. </p></div></article><article class="mt-16 grid grid-cols-1 sm:grid-cols-4 gap-6" data-v-c5b5856d><!--[-->`);
      ssrRenderList(whyChooseUs.value, (item, i) => {
        _push(`<div class="${ssrRenderClass([{ "bg-secondary": i == 1, "bg-primary": i == 3 }, "card bg-[#F3F3F3] shadow rounded-sm"])}" data-v-c5b5856d><div class="card-body" data-v-c5b5856d><h2 class="${ssrRenderClass([{ "!text-white/90": i == 1, "!text-white/90": i == 3 }, "card-title text-dark text-xl mb-4"])}" data-v-c5b5856d>${ssrInterpolate(item.title)}</h2><p class="${ssrRenderClass([{ "text-white/90": i == 1, "!text-white/90": i == 3 }, "prose text-sm"])}" data-v-c5b5856d>${ssrInterpolate(item.content)}</p></div></div>`);
      });
      _push(`<!--]--></article></div></section><section class="hero" style="${ssrRenderStyle({ "background-image": "url(/img/hero-footer-bg.png)" })}" data-v-c5b5856d><div class="hero-overlay bg-[#d61b24] bg-opacity-80" data-v-c5b5856d></div><div class="hero-content text-center text-neutral-content py-10" data-v-c5b5856d><div class="max-w-md" data-v-c5b5856d><h4 class="mb-5 text-xl font-medium" data-v-c5b5856d>Become a Partner</h4><p class="text-4xl font-bold mb-5" data-v-c5b5856d> Get access wide range of consistent partnership benefits </p><button class="btn btn-primary capitalize px-8 rounded-3xl" data-v-c5b5856d>Become A Partner</button></div></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c5b5856d"]]);

export { index as default };
//# sourceMappingURL=index-a23d272d.mjs.map

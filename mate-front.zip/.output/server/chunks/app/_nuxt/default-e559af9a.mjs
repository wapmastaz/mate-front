import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-afaf4e47.mjs';
import { useSSRContext, ref, mergeProps, withCtx, createVNode, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '../server.mjs';
import 'vue-router';

const _imports_0 = "" + publicAssetsURL("img/logo.svg");
const _sfc_main$2 = {
  __name: "AppHeader",
  __ssrInlineRender: true,
  setup(__props) {
    const navItems = ref([
      { name: "Home", to: "/" },
      { name: "About Us", to: "/about" },
      { name: "Our Services", to: "/service" },
      { name: "FAQ", to: "/faq" },
      { name: "Contact Us", to: "/contact" }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "navbar bg-base-100" }, _attrs))} data-v-917e0e8a><div class="container mx-auto px-4" data-v-917e0e8a><div class="navbar-start" data-v-917e0e8a><div class="dropdown" data-v-917e0e8a>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-60" alt="" data-v-917e0e8a${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "w-60",
                alt: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<ul tabindex="0" class="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52" data-v-917e0e8a><!--[-->`);
      ssrRenderList(navItems.value, (navItem, i) => {
        _push(`<li data-v-917e0e8a>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: navItem.to
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(navItem.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(navItem.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></div><div class="navbar-center hidden lg:flex" data-v-917e0e8a><ul class="menu menu-horizontal px-1" data-v-917e0e8a><!--[-->`);
      ssrRenderList(navItems.value, (navItem, i) => {
        _push(`<li data-v-917e0e8a>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "rounded-none px-4 text-dark/90 text-base",
          to: navItem.to
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(navItem.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(navItem.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div><div class="flex navbar-end" data-v-917e0e8a>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/partner",
        class: "btn btn-sm btn-primary rounded-3xl capitalize h-10"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Become a partner`);
          } else {
            return [
              createTextVNode("Become a partner")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></header>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppHeader.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-917e0e8a"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_link = __nuxt_component_0$1;
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "footer justify-center grid-cols-2 sm:grid-cols-4 p-10 bg-dark text-base-content" }, _attrs))} data-v-178feccd><aside class="" data-v-178feccd>`);
  _push(ssrRenderComponent(_component_nuxt_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-60" alt="" data-v-178feccd${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0,
            class: "w-60",
            alt: ""
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<p class="prose text-white/90 mt-5" data-v-178feccd>At Dunvipe Group, we\u2019re committed to delivering excellence that helps navigate the dynamic landscape of the energy and technological industries.</p></aside><nav data-v-178feccd><header class="footer-title" data-v-178feccd>Services</header><a class="link link-hover" data-v-178feccd>Branding</a><a class="link link-hover" data-v-178feccd>Design</a><a class="link link-hover" data-v-178feccd>Marketing</a><a class="link link-hover" data-v-178feccd>Advertisement</a></nav><nav data-v-178feccd><header class="footer-title" data-v-178feccd>Company</header><a class="link link-hover" data-v-178feccd>About us</a><a class="link link-hover" data-v-178feccd>Contact</a><a class="link link-hover" data-v-178feccd>Jobs</a><a class="link link-hover" data-v-178feccd>Press kit</a></nav><nav data-v-178feccd><header class="footer-title" data-v-178feccd>Legal</header><a class="link link-hover" data-v-178feccd>Terms of use</a><a class="link link-hover" data-v-178feccd>Privacy policy</a><a class="link link-hover" data-v-178feccd>Cookie policy</a></nav></footer>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppFooter.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-178feccd"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AppHeader = __nuxt_component_0;
  const _component_AppFooter = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-e559af9a.mjs.map

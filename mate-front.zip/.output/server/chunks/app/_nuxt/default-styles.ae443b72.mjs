const AppHeader_vue_vue_type_style_index_0_scoped_917e0e8a_lang = ".router-link-exact-active[data-v-917e0e8a]{border-bottom:2px solid #6ba612}";

const AppFooter_vue_vue_type_style_index_0_scoped_178feccd_lang = ".footer[data-v-178feccd]{row-gap:4rem}";

const defaultStyles_ae443b72 = [AppHeader_vue_vue_type_style_index_0_scoped_917e0e8a_lang, AppFooter_vue_vue_type_style_index_0_scoped_178feccd_lang];

export { defaultStyles_ae443b72 as default };
//# sourceMappingURL=default-styles.ae443b72.mjs.map

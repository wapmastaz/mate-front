const client_manifest = {
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_nuxt-link.ae3f3f72.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.ae3f3f72.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.27cc1aaf.js"
    ]
  },
  "_swiper-vue.27cc1aaf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.c10309bc.css"
    ],
    "file": "swiper-vue.27cc1aaf.js"
  },
  "swiper-vue.c10309bc.css": {
    "file": "swiper-vue.c10309bc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_vue.f36acd1f.0edd4c86.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.0edd4c86.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.27cc1aaf.js"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.c356128e.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.d169ee50.js",
    "imports": [
      "_nuxt-link.ae3f3f72.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.27cc1aaf.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.c356128e.css": {
    "file": "default.c356128e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.95c28eb4.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.251b05d3.js",
    "imports": [
      "_nuxt-link.ae3f3f72.js",
      "_vue.f36acd1f.0edd4c86.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.27cc1aaf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.95c28eb4.css": {
    "file": "error-404.95c28eb4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.e798523c.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.64fc0e3b.js",
    "imports": [
      "_vue.f36acd1f.0edd4c86.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.27cc1aaf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.e798523c.css": {
    "file": "error-500.e798523c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.62d5407c.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.62d5407c.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.dfa21d00.js",
    "imports": [
      "_swiper-vue.27cc1aaf.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.62d5407c.css": {
    "file": "entry.62d5407c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "about.02409d32.js",
    "imports": [
      "_nuxt-link.ae3f3f72.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.27cc1aaf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.d49cc23f.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.57b6959d.js",
    "imports": [
      "_swiper-vue.27cc1aaf.js",
      "_nuxt-link.ae3f3f72.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.d49cc23f.css": {
    "file": "index.d49cc23f.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.c10309bc.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
